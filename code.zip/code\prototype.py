import pandas as pd
from datetime import datetime, timedelta

"""
=== AGENT BRAIN DECISION RULES ===
1. balance - minimum >= amount AND 90-day forecast stays above minimum
   => affordable_now, full_payment
2. Same but allows_partial_payment and buffer < amount
   => affordable_with_plan, partial_payment
3. Balance becomes safe later within 90 days
   => affordable_later, wait
4. Never becomes safe
   => not_affordable, not_recommended
"""


def forecast_90_days(user_id, request_date_str, initial_balance, min_balance, payment_amount_today, events_df):
    """
    Simulates daily balance starting at request_date for 90 days after paying payment_amount_today.
    Applies scheduled/pending financial events on their respective dates.
    Returns the minimum projected balance over the 90-day window.
    """
    start_date = datetime.strptime(request_date_str, '%Y-%m-%d').date()
    end_date = start_date + timedelta(days=90)
    
    u_events = events_df[events_df['user_id'] == user_id]
    
    events_by_date = {}
    for _, event in u_events.iterrows():
        status = str(event['status']).lower()
        if status in ['cancelled']:
            continue
        
        if pd.notnull(event['event_date']):
            e_date = datetime.strptime(str(event['event_date']), '%Y-%m-%d').date()
            if start_date <= e_date <= end_date:
                amount = float(event['amount']) if pd.notnull(event['amount']) else 0.0
                direction = str(event['direction']).lower()
                net_change = amount if direction == 'credit' else -amount
                
                # Include future pending and scheduled events
                if status in ['scheduled', 'pending']:
                    events_by_date.setdefault(e_date, 0.0)
                    events_by_date[e_date] += net_change

    current_bal = initial_balance - payment_amount_today
    min_bal = current_bal
    
    curr_date = start_date
    salary_applied_date = None
    
    while curr_date <= end_date:
        if curr_date in events_by_date:
            net = events_by_date[curr_date]
            current_bal += net
            if net > 0:
                salary_applied_date = curr_date
        if current_bal < min_bal:
            min_bal = current_bal
        curr_date += timedelta(days=1)
        
    return min_bal, salary_applied_date


def evaluate_request(request_row, profiles_df, events_df):
    user_id = request_row['user_id']
    req_date = request_row['request_date']
    req_amount = float(request_row['requested_amount'])
    allows_partial = str(request_row['allows_partial_payment']).lower() == 'true'
    
    prof = profiles_df[profiles_df['user_id'] == user_id].iloc[0]
    avail_balance = float(prof['current_available_balance'])
    min_balance = float(prof['minimum_balance_to_keep'])
    
    buffer_today = max(0.0, avail_balance - min_balance)
    
    # 90-day forecast after full payment today
    min_projected, salary_date = forecast_90_days(
        user_id, req_date, avail_balance, min_balance, req_amount, events_df
    )
    
    # Rule 1 Check: Full Payment Today
    if req_amount <= buffer_today and min_projected >= min_balance:
        return {
            'request_id': request_row['request_id'],
            'amount_safe_to_pay': req_amount,
            'affordability_status': 'affordable_now',
            'recommended_payment_method': 'full_payment',
            'payment_plan': f"{req_date}:{req_amount:g}",
            'earliest_date_for_full_payment': req_date,
            'spending_changes_needed': 'none',
            'decision_explanation': (
                f"Pay {req_amount:g} today. Balance stays above {min_balance:g} "
                f"minimum throughout 90-day forecast (Salary credit on {salary_date})."
            )
        }
        
    # Max safe amount today before optional spending changes
    min_proj_zero_pay, _ = forecast_90_days(
        user_id, req_date, avail_balance, min_balance, 0.0, events_df
    )
    amount_safe_today = min(req_amount, max(0.0, min_proj_zero_pay - min_balance))
    
    return {
        'request_id': request_row['request_id'],
        'amount_safe_to_pay': amount_safe_today,
        'affordability_status': 'affordable_with_plan' if (allows_partial and amount_safe_today > 0) else 'affordable_later',
        'recommended_payment_method': 'partial_payment' if (allows_partial and amount_safe_today > 0) else 'wait',
        'payment_plan': 'none',
        'earliest_date_for_full_payment': req_date,
        'spending_changes_needed': 'none',
        'decision_explanation': 'Requires further plan evaluation.'
    }


def main():
    samples_df = pd.read_csv('dataset/sample_requests.csv')
    profiles_df = pd.read_csv('dataset/financial_profiles.csv')
    events_df = pd.read_csv('dataset/financial_events.csv')
    
    print("=== TESTING USER 01 (request_01) ===")
    req_01 = samples_df[samples_df['user_id'] == 'user_01'].iloc[0]
    res_01 = evaluate_request(req_01, profiles_df, events_df)
    print("Prediction:", res_01)
    print("Expected:   amount_safe_to_pay=25256, affordability_status=affordable_now, recommended_payment_method=full_payment")
    
    print("\n=== TESTING USER 02 (request_02) ===")
    req_02 = samples_df[samples_df['user_id'] == 'user_02'].iloc[0]
    res_02 = evaluate_request(req_02, profiles_df, events_df)
    print("Prediction:", res_02)
    print("Expected:   amount_safe_to_pay=17229139.2, affordability_status=affordable_with_plan")


if __name__ == '__main__':
    main()
